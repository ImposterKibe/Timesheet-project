import { Router } from 'express';
import commonController from '../controllers/commonController';

class commonRoutes {

    public router: Router = Router();

    constructor() {
        this.config();
    }

    config(): void {
        this.router.post('/login', commonController.login);
        this.router.post('/logout', commonController.logout);

        this.router.get('/getProjSpecificUser/:id',commonController.checkSession, commonController.getProjSpecificUser);
        this.router.get('/getServerTime', commonController.checkSession,commonController.getServerTime);
        this.router.get('/getAllDurations', commonController.checkSession,commonController.getAllDurations);
    }

}

const commonRouters = new commonRoutes();
export default commonRouters.router