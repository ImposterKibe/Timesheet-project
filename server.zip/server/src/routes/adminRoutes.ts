import { Router } from 'express';
import adminController from '../controllers/adminController';

class AdminRoutes {

    public router: Router = Router();

    constructor() {
        this.config();
    }

    config(): void {
        this.router.get('/allusers', adminController.userlist);
        this.router.get('/oneuser/:id', adminController.getOneUser);
        this.router.post('/adduser', adminController.createUser);
        this.router.put('/updateuser/:id', adminController.updateUser);
        this.router.put('/deleteuser/:id', adminController.deleteUser);

        this.router.get('/allprojects', adminController.prolist);
        this.router.get('/oneproject/:id', adminController.getOnePro);
        this.router.post('/addproject', adminController.createProject);
        this.router.put('/projects/:id', adminController.updateSingleProject);
        this.router.put('/deleteproject/:id', adminController.deleteproject);
        this.router.get('/roles', adminController.rolelist);

        //mapping
        this.router.get('/getusermap/:id', adminController.getUserMap);
        this.router.put('/mapProToUser/:id', adminController.mapProToUser);

        //Unmapping
        this.router.get('/getuserunmap/:id', adminController.getUserUnMap);
        this.router.put('/unmapProToUser/:id', adminController.unmapProToUser);

        //admin/timesheets
        this.router.post('/getData', adminController.datalist);

        /*this.router.put('/mapnewProjects/:id', adminController.mapnewProjects);
        this.router.put('/updateProjects/:id', adminController.updateProjects);
        this.router.put('/updateProjectToOne/:id', adminController.updateProjectToOne);
        this.router.put('/updateProjectToZero/:id', adminController.updateProjectToZero);

        
        this.router.get('/getProjectMapData/:pro', adminController.getProjectMapDatalist);
        this.router.get('/getUserMapData/:user', adminController.getUserMapDatalist);*/
    }

}

const adminRoutes = new AdminRoutes();
export default adminRoutes.router