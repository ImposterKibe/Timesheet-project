import mysql from 'mysql';
// import keys from './keys';

import store from './serverConfig'

const connection = mysql.createConnection(store.database);
connection.connect(function(err) {
  if (err) {
    console.error('DB error connecting: ' + err.message);
    return;
  }

  console.log('DB connected ');
});

export default connection;
