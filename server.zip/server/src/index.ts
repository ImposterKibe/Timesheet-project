import express, { Application } from 'express';
import morgan from 'morgan';
import cors from 'cors';
import session from "express-session";


import indexRoutes from './routes/indexRoutes';
import timesheetRoutes from './routes/timesheetRoutes';
import adminRoutes from './routes/adminRoutes';

import commonRoutes from './routes/commonRoutes';

import CommonController from './controllers/commonController'

import store from './serverConfig'


class Server {

    public app: Application;

    constructor() {
        this.app = express();
        this.config();
        this.routes();
    }

    config(): void {
        this.app.set('port', process.env.PORT || store.sessionInfo.serverProt);
        this.app.use(morgan('dev'));
        this.app.use(cors());
        this.app.use(express.json());
        this.app.use(express.urlencoded({ extended: false }));

        this.app.use(session({
            secret: store.sessionInfo.sessionKey,
            resave: false,
            saveUninitialized: true,
            cookie: { maxAge:store.sessionInfo.maxAge } //3hrs
        }));

        // this.app.use(session({
        //     secret: 'timesheet',
        //     name: 'timesheet',
        //     proxy: true,
        //     resave: false,
        //     saveUninitialized: true
        // }));
    }

    routes(): void {
        this.app.use('/', indexRoutes);
        this.app.use('/api/timesheet', CommonController.checkSession, timesheetRoutes);
        this.app.use('/api/admin', CommonController.checkSession, adminRoutes);
        this.app.use('/api/common', commonRoutes);
    }

    start(): void {
        this.app.listen(this.app.get('port'), () => {
            console.log('Server on port', this.app.get('port'));
        })
    }
}

const server = new Server();
server.start();



