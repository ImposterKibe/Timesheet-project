export default {

    database: {
        host: '172.16.1.35',
        user: 'ksangeetha',
        password: 'ksangeetha@#987',
        database: 'time_sheet',
        timezone: 'Z',
        multipleStatements: true
    },
    jwttoken: {
        "secretKey": "shyamkumar",
        "logInTokExpiresIn": "3d", //ex: m h d
    },
    sessionInfo: {
        "maxAge": 3000 * 60 * 60 * 3, //three hr
        "sessionKey": "shyamkumarreddy1997",
        "serverProt": 3900,
    }
}