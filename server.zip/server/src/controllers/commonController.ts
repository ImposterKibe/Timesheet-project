import { Request, Response } from 'express';
import connection from '../database';
import session from "express-session";
import jwt from "jsonwebtoken"

import store from "../serverConfig"



class CommonController {

    public async login(req: Request, res: Response) {
        console.log("server side login ", req.body);
        var _this = this
        connection.query('SELECT * FROM users WHERE user_id = ? AND password=? AND status=1', [req.body.user_id, req.body.password], function (err, result, fields) {
            if (!err) {
                if (result.length > 0) {
                    //for session
                    const payload = {
                        userid: result[0].user_id,
                        uname: result[0].user_name,
                        role: result[0].role_id
                    }

                    let token = jwt.sign(payload, store.jwttoken.secretKey, {
                        expiresIn: store.jwttoken.logInTokExpiresIn
                    })

                    // console.log("token is ", token,store.jwttoken.secretKey,store.jwttoken.logInTokExpiresIn);
                    if (req.session) {
                        req.session.user = result[0];
                        req.session.token = token;
                        req.session.save();
                    }
                    // console.log("req.session is ",req.session,req.session.user.user_name);

                    return res.json({ "res": result, "token": token });
                }
                else {
                    res.status(404).json({ text: "The User does not exist!" });
                }
            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async logout(req: Request, res: Response) {
        console.log("User logout ")
        if (req.session)
            await req.session.destroy(function () {
                return res.json({ status: "user logged out" });
            });
    }

    public async getProjSpecificUser(req: Request, res: Response) {
        const { id } = req.params;
        connection.query(`SELECT projects.project_id,projects.project_name,projects.description,projects.created_date,
        projects.updated_date,projects.status FROM projects INNER JOIN user_projects  ON projects.project_id=user_projects.project_id
        where user_projects.user_id=? and projects.status=1 `, id, function (err, result, fields) {
                if (!err) {
                    return res.json(result);
                }
                if (err) {
                    console.log(err)
                }
            })
    }

    public async getAllDurations(req: Request, res: Response) {
        var jsonObj = {
            "todayDur": "",
            "yesterdayDur": "",
        }

        await connection.query('SELECT (sum(duration)/60) as total FROM time_sheet.time_sheet where date=curdate()', async function (err, result, fields) {
            jsonObj['todayDur'] = result[0]['total'];
            await connection.query('SELECT (sum(duration)/60) as total FROM time_sheet.time_sheet where date=curdate() - interval(1) day', function (err, result, fields) {
                jsonObj['yesterdayDur'] = result[0]['total'];
                console.log("jsonObj is ", jsonObj);
                return res.json({ "data": jsonObj })
            })
        })

    }

    public async getServerTime(req: Request, res: Response) {
        var date = new Date().toUTCString();
        var dateformated = date.substring(17, 25);
        var hms = dateformated;
        var a = hms.split(':');
        var seconds = (+a[0] + 5) * 60 * 60 + (+a[1] + 30) * 60;
        //  console.log(date,dateformated,seconds)
        var d = seconds;
        var dur;
        const HOUR = 60 * 60;
        const MINUTE = 60;
        var minutesInSeconds = d % HOUR;
        var hours = Math.floor(d / HOUR);
        var minutes = Math.floor(minutesInSeconds / MINUTE)
        if (hours < 10) {
            var hr = "" + "0" + hours;
        }
        else {
            var hr = "" + hours;
        }
        if (minutes < 10) {
            var min = "" + "0" + minutes;
        }
        else {
            var min = "" + minutes;
        }
        dur = hr + ":" + min + ":00";
        // console.log("dur",dur)
        var x = new Date();
        var y = x.getFullYear().toString();
        var m = (x.getMonth() + 1).toString();
        var dt = x.getDate().toString();
        (dt.length == 1) && (dt = '0' + dt);
        (m.length == 1) && (m = '0' + m);
        var yyyymmdd = y + '-' + m + '-' + dt;
        //    console.log("yyyymmdd",yyyymmdd)
        res.json({ timevalue: dur, datevalue: yyyymmdd });
    }

    public async checkSession(req: Request, res: Response, next: any) {
        console.log("req.headers is ", req.headers.authorization, typeof (req.headers.authorization));
        if (req.headers.authorization == 'null' || req.headers.authorization == undefined) {
            return res.json({ "message": "Please login", "statusCode": 515 });
        }
        else {
            try {
                // var decoded=jwt.verify(req.headers['authorization'], message['confStore']['secretKeyApp'])  
            }
            catch (csErr) {

            }
            // return res.json({ "message":"Please login","statusCode": 515 });
            next();
        }
        // return true
    }

}

const commonController = new CommonController();
export default commonController;