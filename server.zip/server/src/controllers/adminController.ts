import { Request, Response } from 'express';
import connection from '../database';

class AdminController {
    public async userlist(req: Request, res: Response) {
        connection.query('SELECT * FROM users WHERE status=1', function (err, result, fields) {
            if (!err) {
                return res.json(result);
            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async getOneUser(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        connection.query('SELECT * FROM users WHERE user_id = ? and status=1', [id], function (err:any, result:any, fields:any) {
            if (!err) {
                if (result.length > 0) {
                    return res.json(result[0]);
                }
                else {
                    res.status(404).json({ text: "The User does not exist!" });
                }
            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async createUser(req: Request, res: Response): Promise<void> {
        req.body.password = "qtx@123"
        req.body.status = 1
        console.log("request", req.body);
        connection.query('INSERT INTO users set ?', [req.body], function (err, result, fields) {
            if (!err) {
                connection.commit(function (err) {
                    if (err) {
                        connection.rollback(function () {
                            throw err;
                        });
                    }
                    console.log('Creating User Completed.');
                    return res.json(result);
                });
            }
            if (err) {
                console.log("ERROR CAME ", err.code);
                res.json({ message: 'user already exist' });
            }
        })
    }
    public async updateUser(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        console.log("in update", id, req.body)
        //return res.json({"status":"done"})
        connection.query('UPDATE users set user_name=?,updated_date=?,role_id=? WHERE user_id = ?', [req.body.user_name, req.body.updated_date, req.body.role_id, id], function (err, result, fields) {
            if (!err) {
                //console.log("res",result)
                connection.commit(function (err) {
                    if (err) {
                        connection.rollback(function () {
                            throw err;
                        });
                    }
                    console.log('Updating User Done.');
                    return res.json(result);
                });

            }
            if (err) {
                console.log("ERROR CAME ", err.code);
                res.json({ message: 'user already exist' });
            }
        })
    }

    public async deleteUser(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        // console.log("in delete",id,req.body,req.body.updated_date)
        connection.query('UPDATE users set status=0,updated_date=? WHERE user_id = ?', [req.body.updated_date, id], async function (err, result, fields) {
            if (!err) {
                await connection.commit(async function (err) {
                    if (err) {
                        connection.rollback(function () {
                            throw err;
                        });
                    }
                    // await connection.query('update time_sheet.user_projects set status=0 where user_id=?',[id]);
                    // await connection.query('COMMIT');
                    console.log('Deleting User Done.(status 0 <-> 1)');
                    return res.json(result);
                });
            }
            if (err) {
                console.log("ERROR CAME ", err.code);
                res.json({ message: 'user already exist' });
            }
        })

    }


    public async prolist(req: Request, res: Response) {
        connection.query('SELECT * FROM projects WHERE status=1', function (err, result, fields) {
            if (!err) {
                connection.commit(function (err) {
                    if (err) {
                        connection.rollback(function () {
                            throw err;
                        });
                    }
                    console.log('Selected all projects list');
                    return res.json(result);
                });
            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async getOnePro(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        connection.query('SELECT * FROM projects WHERE project_id = ?', [id], function (err, result, fields) {
            if (!err) {
                if (result.length > 0) {
                    return res.json(result[0]);
                }
                else {
                    res.status(404).json({ text: "The project does not exist!" });
                }
            }
            if (err) {
                console.log(err)
            }
        })
    }


    public async createProject(req: Request, res: Response): Promise<void> {
        req.body.status = 1
        console.log("request", req.body);
        connection.query('INSERT INTO projects set ?', [req.body], function (err, result, fields) {
            if (!err) {
                connection.commit(function (err) {
                    if (err) {
                        connection.rollback(function () {
                            throw err;
                        });
                    }
                    console.log('Created One project.');
                    return res.json(result);
                });
            }
            if (err) {
                console.log("ERROR CAME ", err.code);
                res.json({ message: 'user already exist' });
            }

        })
    }

    public async deleteproject(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        //console.log(id,req.body,req.body.updated_date)
        await connection.query('UPDATE projects set status=0,updated_date=? WHERE project_id = ?', [req.body.updated_date, id]);
        await connection.query("COMMIT");
        // await connection.query('update time_sheet.user_projects set status=0 where project_id=?',[id]);
        // await connection.query('COMMIT');
        res.json({ message: 'The project was deleted!' });
    }


    public async rolelist(req: Request, res: Response) {
        connection.query('SELECT * FROM roles', function (err, result, fields) {
            if (!err) {
                return res.json(result);
            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async mapProToUser(req: Request, res: Response): Promise<any> {
        console.log("res.params and req.body is ", req.params, req.body);
        const userId = req.body['user_id']
        var projId = req.body['project_id']
        //projId='100'
        connection.query(`SELECT * FROM time_sheet.user_projects where user_id=? and project_id=?`, [userId, projId], async function (err, result, fields) {
            if (err) {
                return res.json({ "message": "project not mapped to user" })
            }
            else {
                if (result.length == 0) {   //we need to create new row
                    req.body['status'] = 1
                    await connection.query('INSERT INTO user_projects set ?', [req.body]);
                    await connection.query("COMMIT");
                }
                else {//already existed update status ->1
                    await connection.query(`UPDATE user_projects set status=1 where user_id=? and project_id=?`, [userId, projId]);
                    await connection.query("COMMIT");
                }
                console.log("inside ", err);
                console.log("inside ", result.length);
                return res.json({ "message": "project mapped to given user" });
            }

        })

    }

    public async getUserMap(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        console.log(id)

        connection.query(`SELECT b1.project_name,b1.project_id FROM time_sheet.projects as b1 where  b1.status=1 and b1.project_id in (select b2.project_id from user_projects as b2 where b2.status=0 and b2.user_id=?)
            Union
            SELECT b1.project_name,b1.project_id FROM time_sheet.projects as b1 where b1.status=1 and b1.project_id not in (select b2.project_id from user_projects as b2 where b2.user_id=?)
            `, [id, id], function (err, result, fields) {
                if (!err) {
                    return res.json(result);
                }
                if (err) {
                    console.log(err)
                }
            })

        /* const user = await connection.query(`SELECT user_projects.id,user_projects.project_id,user_projects.status,projects.project_name FROM projects INNER JOIN user_projects
                                           ON projects.project_id=user_projects.project_id  WHERE user_projects.user_id = ?`, [id]);
                   if(user.length > 0){
                       return res.json(user);
                   }
           console.log("user is ",user);
               res.json({notexist: 'The user is not mapped to any project'});
          // res.status(404).json({text: "The user does not exist!"});*/

    }

    public async getUserUnMap(req: Request, res: Response): Promise<any> {
        console.log("res.params and req.body is ", req.params, req.body);
        const { id } = req.params;
        connection.query(`SELECT b1.project_name,b1.project_id FROM time_sheet.projects as b1 where  b1.status=1 and b1.project_id in (select b2.project_id from user_projects as b2 where b2.status=1 and b2.user_id=?)`, [id], function (err, result, fields) {
            if (!err) {
                return res.json(result);
            }
            if (err) {
                console.log(err)
                return res.json({ "status": "Err retieving unmapped projects of user" })
            }
        })
    }

    public async unmapProToUser(req: Request, res: Response): Promise<any> {
        console.log("res.params and req.body is ", req.params, req.body);
        const userId = req.body['user_id']
        var projId = req.body['project_id']
        await connection.query(`UPDATE user_projects set status=0 where user_id=? and project_id=?`, [userId, projId]);
        await connection.query("COMMIT");
        return res.json({ "message": "Project unmapped to user" })
    }

    //Projects functions

    public async updateSingleProject(req: Request, res: Response): Promise<void> {
        console.log(req.body)
        const { id } = req.params;
        await connection.query('UPDATE projects set ? WHERE project_id = ?', [req.body, id]);
        await connection.query("COMMIT");
        res.json({ message: 'The project was updated!' });
    }

    //not required
    public async updateProjects(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        //console.log(req.body.length)
        var len = req.body.length
        //console.log("body",req.body,len,id)
        for (var i = 0; i < len; i++) {
            //console.log("is",i,req.body[i])
            if (req.body[i]['status'] == 0) {
                console.log("0", req.body[i].id)
                await connection.query('UPDATE user_projects set status=1 WHERE id = ?', [req.body[i].id]);
                await connection.query("COMMIT");
                res.json({ message: 'The user-project is updated!' });
            }
            else {
                console.log("1", req.body[i]['id'])
                await connection.query('UPDATE user_projects set status=0 WHERE id = ?', [req.body[i].id]);
                await connection.query("COMMIT");
                res.json({ message: 'The user-project is updated!' });
            }
        }
    }
    //end not reuqired

    public async mapnewProjects(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        delete req.body.id
        console.log("body", req.body, id)
        await connection.query('INSERT INTO user_projects set ?', [req.body]);
        await connection.query("COMMIT");
        res.json({ message: 'Usermapping is done successfully' });
    }

    public async updateProjectToOne(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        delete req.body.id
        console.log("TO 1", req.body, id)
        await connection.query('UPDATE user_projects set status=1 WHERE id = ?', [id]);
        await connection.query("COMMIT");
        res.json({ message: 'The user-project is updated!' });
    }

    public async updateProjectToZero(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        delete req.body.id
        console.log("to 0", req.body, id)
        await connection.query('UPDATE user_projects set status=0 WHERE id = ?', [id]);
        await connection.query("COMMIT");
        res.json({ message: 'The user-project is updated!' });
    }


    public async datalist(req: Request, res: Response) {
        var uid = req.body.userid
        var pid = req.body.proid
        console.log("data", req.body, "its", uid, pid)

        var query = "", listObj = [], type = ""
        if (uid == '') { //all data with pid
            listObj = [pid]
            query = ` select users.user_id,users.user_name,projects.project_name,projects.description
                    from user_projects
                    inner join projects on projects.project_id=user_projects.project_id
                    inner join users on users.user_id=user_projects.user_id 
                    
                    where user_projects.project_id=? and user_projects.status=1`
            type = "projectid"
        }
        else if (pid == -1) {  //all data with given userid
            listObj = [uid]
            query = ` select users.user_id,users.user_name,projects.project_name,projects.description from
                user_projects inner join projects on projects.project_id=user_projects.project_id inner join users on
                users.user_id=user_projects.user_id 
                where user_projects.user_id=? and user_projects.status=1`
            type = "userid"
        }
        else {//with both uid and proid
            listObj = [uid, pid]
            query = ` select users.user_id,users.user_name,projects.project_name,projects.description from
                user_projects inner join projects on projects.project_id=user_projects.project_id inner join users on
                users.user_id=user_projects.user_id
                where user_projects.user_id=? and user_projects.project_id=? and user_projects.status=1`
            type = "both"
        }
        console.log(query, listObj);
        await connection.query(query, listObj, function (err, result, fields) {
            if (err) {
                return res.json({ "error": err, type: type })
            } else {
                return res.json({ "status": result, type: type })
            }
        });
        // const datalist = await connection.query(` select users.user_id,users.user_name,projects.project_name,projects.description from
        // user_projects inner join projects on projects.project_id=user_projects.project_id inner join users on
        // users.user_id=user_projects.user_id  where user_projects.user_id=? and user_projects.project_id=?`, [uid, pid]);
        // // res.json(datalist);
        // return res.json({"status":"cool"});
    }

    public async getProjectMapDatalist(req: Request, res: Response) {
        var pid = req.params.pro
        const datalist = await connection.query(` select users.user_id,users.user_name,projects.project_name,projects.description from
                    user_projects inner join projects on projects.project_id=user_projects.project_id inner join users on
                    users.user_id=user_projects.user_id  where user_projects.project_id=?`, [pid]);
        res.json(datalist);
    }

    public async getUserMapDatalist(req: Request, res: Response) {
        var uid = req.params.user
        const datalist = await connection.query(` select users.user_id,users.user_name,projects.project_name,projects.description from
            user_projects inner join projects on projects.project_id=user_projects.project_id inner join users on
            users.user_id=user_projects.user_id  where user_projects.user_id=?`, [uid]);
        res.json(datalist);
    }
}

const adminController = new AdminController();
export default adminController;
