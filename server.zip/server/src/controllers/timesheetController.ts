import { Request, Response } from 'express';
import connection from '../database';

class TimesheetController {

    public async list(req: Request, res: Response) {
        const { id } = req.params;
        connection.query(`SELECT time_sheet.timesheet_id,time_sheet.start_time,time_sheet.end_time,time_sheet.description,
        time_sheet.duration,time_sheet.date,projects.project_name FROM time_sheet INNER JOIN projects ON
        time_sheet.project_id=projects.project_id WHERE time_sheet.user_id=? ORDER BY time_sheet.updated_date DESC`, [id], function (err, result, fields) {
                if (!err) {
                    return res.json(result);
                }
                if (err) {
                    console.log(err)
                }
            })

    }

    public async getOne(req: Request, res: Response): Promise<any> {
        const { id } = req.params;
        connection.query('SELECT * FROM time_sheet WHERE timesheet_id = ?', [id], function (err, result, fields) {
            if (!err) {
                if (result.length > 0) {
                    return res.json(result[0]);
                }
                else {
                    res.status(404).json({ text: "The timesheet does not exist!" });
                }

            }
            if (err) {
                console.log(err)
            }
        })
    }

    public async create(req: Request, res: Response): Promise<void> {
        console.log("create req body ", req.body)
        try {
            await connection.query(`SELECT CURRENT_TIMESTAMP`, async function (err, result, fields) {
                var presentDate = new Date(result[0]['CURRENT_TIMESTAMP'])
                // console.log("presentDate is ", presentDate);
                req.body.created_date = presentDate
                // req.body.updated_date = presentDate
                console.log("aft updating ", req.body);
                await connection.query('INSERT INTO time_sheet set ?', [req.body]);
                await connection.query("COMMIT");
                return res.json({ message: 'Timesheet saved' });
            })
        }
        catch (err) {
            console.log("err mode on");
            throw new Error(err)
        }

    }

    public async update(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        console.log("Timesheet update ", req.body, req.params, id);

        await connection.query(`SELECT CURRENT_TIMESTAMP`, async function (err, result, fields) {
            console.log("result is ", new Date(result[0]['CURRENT_TIMESTAMP']));
            // var presentDate = new Date(result[0]['CURRENT_TIMESTAMP'])
            var updatedList = [req.body.start_time, req.body.end_time, req.body.project_id, req.body.description, req.body.duration, id]

            console.log("updatedList is ", updatedList);

            await connection.query(`UPDATE time_sheet set start_time=?,end_time=?,project_id=?,description=?,duration=? WHERE timesheet_id = ?`, updatedList);
            await connection.query("COMMIT");
            res.json({ text: 'The timesheet was updated!' + req.params.id });
        })
    }

    public async getDayWiseData(req: Request, res: Response): Promise<void> {
        const { id } = req.params;
        console.log("Timesheet getDayWiseData ", req.body, req.params, id);

        var query = ""
        if (req.body.day == "today") {
            query = `SELECT ts.timesheet_id,ts.start_time,ts.end_time,ts.duration,ts.description,proj.project_name
                    FROM time_sheet as ts ,projects as proj
                    where date = CURDATE() and ts.project_id=proj.project_id;`
        }
        else if (req.body.day == "yesterday") {
            query = `SELECT ts.timesheet_id,ts.start_time,ts.end_time,ts.duration,ts.description,proj.project_name
                    FROM time_sheet as ts ,projects as proj
                    where date = CURDATE() - INTERVAL 1 DAY  and ts.project_id=proj.project_id;`
        }
        else if (req.body.day == "week") {
            query = `SELECT ts.timesheet_id,ts.start_time,ts.end_time,ts.duration,ts.description,proj.project_name
            FROM time_sheet as ts ,projects as proj
            where (date BETWEEN ( CURDATE() - INTERVAL ( WEEKDAY(CURDATE())+1 ) DAY ) and ( CURDATE() ) )and ts.project_id=proj.project_id;`
        }

        await connection.query(query, async function (err, result, fields) {
            if (err) {
             return res.json({error:"queryErr "+err})   
            }
            console.log("result is ", result.length);
            res.json({ data: result });
        })
    }


    /* public async delete(req: Request, res: Response): Promise<void>{
         const { id } = req.params;
         await pool.query('DELETE FROM timesheet WHERE id = ?', [id]);
         res.json({message: 'The timesheet was deleted!'});
     }*/
}

const timesheetController = new TimesheetController();
export default timesheetController;
